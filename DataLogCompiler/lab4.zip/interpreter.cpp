#include "interpreter.h"

void interpreter::makeRelations(){
    vector<predicate> schemes = Data.returnVector("scheme");
    for(unsigned i=0; i<schemes.size(); ++i){
        vector<parameter> attributes = schemes.at(i).getParams();
        scheme schemer = scheme();
        for(unsigned j=0; j<attributes.size(); ++j){
            string value = attributes.at(j).getThing();
            schemer.push_back(value);
        }
        relation scheme(schemes.at(i).getName(), schemer);
        DB.addRelation(scheme.getName(), scheme);
    }
}

void interpreter::makeTuples(){
    vector<predicate> tuples = Data.returnVector("fact");
    for(unsigned i=0; i<tuples.size(); ++i){
        vector<parameter> values = tuples.at(i).getParams();
        Tuple tupler;
        for(unsigned j=0; j<values.size(); ++j){
            string value = values.at(j).getThing();
            tupler.push_back(value);
        }
        DB.addTupleToRelation(tuples.at(i).getName(), tupler);
    }
}

relation interpreter::evaluateBody(rule ruler){
    vector<predicate> body = ruler.getBody();
    
    relation result = solveQ(body.at(0));
    for(unsigned i=1; i<body.size(); ++i){
        relation f = solveQ(body.at(i));
        result = result.join(f);
    }
    return result;
}

vector<unsigned> interpreter::evaluateHead(rule ruler, scheme rscheme){
    vector<parameter> head = ruler.getHead();
    vector<unsigned> ret;
    for(unsigned i = 0; i<head.size(); ++i){
        for(unsigned j=0; j<rscheme.size(); ++j){
            if(head.at(i).getThing() == rscheme.at(j)){
                ret.push_back(j);
            }
        }
    }
    return ret;
}

void interpreter::evaluateRules(){
    bool FPA;
    int n=0;
    cout << "Rule Evaluation";
    do{
        FPA = false;
        n++;
        for(unsigned i=0; i<rules.size(); ++i){
            string rulest = rules.at(i).toString();
            cout << endl << rulest;
            relation result = evaluateBody(rules.at(i));
            result.setName(rules.at(i).getHeadName());
            vector<unsigned> columns = evaluateHead(rules.at(i), result.getScheme());
            
            result.project(columns);
            string rname = result.getName();
            scheme renames = DB.getScheme(rname);
            result.setScheme(renames);
            
            
            set<Tuple> t = result.getTuples();
            for(set<Tuple>::iterator it=t.begin(); it!=t.end(); ++it){
                int presize = DB.getRelationSize(rname);
                Tuple tup = *it;
                DB.addTupleToRelation(rname, tup);
                int endsize = DB.getRelationSize(rname);
                if(endsize != presize){
                    FPA = true;
                    cout << endl << "  ";
                    for(unsigned i=0; i<tup.size()-1; ++i){
                        cout << renames.at(i) << "=" << tup.at(i) << ", ";
                    }
                    cout << renames.at(tup.size()-1) << "=" << tup.at(tup.size()-1); 
                }
            }
            
        }
    }while(FPA);
    cout << endl << endl << "Schemes populated after " << n << " passes through the Rules." <<endl<<endl;

}



void interpreter::evaluateQueries(){
    cout << "Query Evaluation" << endl;

    for(unsigned i=0; i<queries.size(); ++i){
        string query = queries.at(i).toString() + "?";
        if(i==0){
            cout << query << " ";
        }
        else{
            cout << endl << query << " ";
        }
        relation result = solveQ(queries.at(i));
        
        if(result.getSize()==0){
            cout << "No";
        }
        else if (result.getSize() != 0 && !emptiness){
            cout << "Yes(" << result.getSize() << ")";
            emptiness = true;
        }
        else{
            cout << "Yes(" << result.getSize() << ")";
            result.toString();
        }
    }
}

relation interpreter::solveQ(predicate q){
    map<string,int> variables;
    string nombre = q.getName();
    vector<parameter> params = q.getParams();
    relation r = DB.getRelation(nombre);
    vector<string> names;
    emptiness = true;
    vector<unsigned> columns;
    for(unsigned i=0; i<params.size(); ++i){
        string vid = params.at(i).getThing();
        if(params.at(i).isConstant()){
            r.select1(vid, i);
        }
        else if(variables.empty() || variables.find(vid) == variables.end()){
            variables[vid] = i;
            names.push_back(vid);
            columns.push_back(i);
        }
        else{
            r.select2(variables.at(vid), i);
        }
    }
    if(variables.empty() && r.getSize()>0){
        emptiness = false;
        return r;
    }
    
    if(columns.size()>0){
        r.project(columns);
        r.renamer(names);
    }
    return r;
}
