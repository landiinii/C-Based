#ifndef TUPLE_H
#define TUPLE_H
#include <vector>
#include <string>
#include <iostream>
using namespace std;

class Tuple : public vector<string>
{
    
    private:

    public:
    
};
#endif